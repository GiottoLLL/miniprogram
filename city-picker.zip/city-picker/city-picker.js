var json = require('../../DATA/city-picker.data.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:'',
    title:[
      {sign:"province", show:"省"},
      {sign:"city", show:"城市"},
      {sign:"district",show:"区县"},
      {sign:"county",show:"镇"}
    ],
    action: 'province',
    province: {},
    list1: [],
    list2: [],
    list3: [],
    list4: [],
    check: false
  },

  // action:function(e) {
  //   var that = this,
  //   sign = e.currentTarget.dataset.sign
  //   that.setData({
  //     action: sign
  //   })
  // },
  action: function (e) {
    var that = this,
    flag = that.data.check
    that.setData({
      check:!flag,
      action:'province'
    })
  },

  pick:function(e) {
    var that = this,
    action = that.data.action,
    id = e.currentTarget.dataset.id,
    address = that.data.address,
    add = e.currentTarget.dataset.add,
    flag = that.data.check
    // 选择省
    action == "province" ? that.setData({
      list2: json.districts[id],
      action:"city",
      address:add
    }) : "" 
    // 选择城市
    action == "city" ? (
      json.districts[id] ? that.setData({
        list3: json.districts[id],
        action: "district",
        address: address + add
      }) : that.setData({
        action: "district",
        address: address + add,
        check:!flag
      })
    ) : ""
    // 选择区县
    action == "district" ? (
      json.districts[id] ? that.setData({
        list4: json.districts[id],
        action: "county",
        address: address + add
      }) : that.setData({
        action: "county",
        address: address + add,
        check: !flag
      })
     ): ""
    //  选择镇
    action == "county" ? that.setData({
        address: address + add,
        check: !flag
      }) : ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      list1: json.districts[86]
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})